# Loteria V4

Quatro modalidades: Lotofácil, Mega-Sena, Quina e Timemania. Temas Light e Dark.

## Publicação

Envie o conteúdo desta pasta para a raiz do repositório GitHub, substituindo `index.html` e `update_results.py`, adicionando `app.js` e substituindo `.github/workflows/update.yml`. Em GitHub Actions, execute **Atualizar resultados das loterias**. O site carrega `data/lotofacil.json`, `data/megasena.json`, `data/quina.json` e `data/timemania.json` após a execução.

Os jogos existentes da Lotofácil são migrados uma vez do armazenamento local anterior. Faça backup antes de atualizar. Os jogos permanecem apenas no navegador.

**Atenção à Timemania:** o seletor de times usa os nomes encontrados no histórico de resultados; a relação oficial de times participantes pode mudar. Antes de registrar aposta real, confira a lista vigente na Caixa. A conferência de Time do Coração depende da identificação do time nos dados oficiais.
