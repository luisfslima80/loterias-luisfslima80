"""Baixa resultados oficiais para as quatro modalidades; executado no GitHub Actions."""
import json
import os
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE = 'https://servicebus2.caixa.gov.br/portaldeloterias/api/'
MODES = {'lotofacil': 15, 'megasena': 6, 'quina': 5, 'timemania': 7}
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'}

def get(mode, number=None):
    url = BASE + mode + ('/' + str(number) if number is not None else '')
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=30) as response:
        return json.load(response)

def valid(row, count):
    return isinstance(row, dict) and isinstance(row.get('numero'), int) and isinstance(row.get('listaDezenas'), list) and len(row['listaDezenas']) == count

def main():
    successes = 0
    for mode, count in MODES.items():
        out = Path('data') / (mode + '.json')
        old = []
        if out.exists():
            try:
                old = json.loads(out.read_text(encoding='utf-8')).get('results', [])
            except (OSError, ValueError):
                pass
        existing = {x['numero']: x for x in old if valid(x, count)}
        try:
            latest = get(mode)
            if not valid(latest, count):
                raise ValueError('Resposta oficial inesperada')
            existing[latest['numero']] = latest
            for number in range(latest['numero'] - 1, max(0, latest['numero'] - 100), -1):
                if number in existing:
                    continue
                try:
                    item = get(mode, number)
                    if valid(item, count):
                        existing[number] = item
                except Exception as exc:
                    print(mode, number, str(exc))
                time.sleep(.12)
            rows = [existing[n] for n in sorted(existing, reverse=True) if n <= latest['numero']][:100]
            out.parent.mkdir(parents=True, exist_ok=True)
            temp = out.with_suffix('.tmp')
            temp.write_text(json.dumps({'updated_at': datetime.now(timezone.utc).isoformat(), 'results': rows}, ensure_ascii=False), encoding='utf-8')
            os.replace(temp, out)
            print(mode, len(rows), 'concursos')
            successes += 1
        except Exception as exc:
            print('ERRO', mode, str(exc), 'dados anteriores preservados')
    if not successes:
        raise RuntimeError('Nenhuma modalidade atualizada')

if __name__ == '__main__':
    main()
